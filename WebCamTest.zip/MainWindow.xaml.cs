﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

// OpenCV 사용을 위한 using
using OpenCvSharp;
using OpenCvSharp.WpfExtensions;
using System.Windows.Threading;

namespace WebCamTest
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        VideoCapture cam;
        Mat frame;
        DispatcherTimer timer;
        bool is_initCam, is_initTimer;
        Mat previousFrame;
        
        private DateTime lastCaptureTime = DateTime.MinValue; // 마지막 캡처 시간
        private TimeSpan captureDelay = TimeSpan.FromSeconds(5); // 다음 캡처까지의 딜레이 시간 (5초로 설정)
        private bool a4DetectedFlag = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void windows_loaded(object sender, RoutedEventArgs e)
        {
            // 기존에 있던 카메라 및 타이머 초기화 코드
            is_initCam = init_camera();
            is_initTimer = init_Timer(0.01);

            if (is_initTimer && is_initCam)
            {
                previousFrame = new Mat();
                timer.Start();
            }

            //// 테스트 데이터 ListBox에 추가하는 메서드 호출
            //AddTestDataToListBox();
        }

        //private void AddTestDataToListBox()
        //{
        //    // 서버로부터 받았다고 가정한 데이터
        //    string color = "붉은색";
        //    string shape = "사각형";
        //    int id = 1; // 고유번호 예시
        //    // ListBox에 데이터 추가
        //    RedBox.Items.Add(color);
        //    SquareBox.Items.Add(shape);
        //}

        private bool init_Timer(double interval_ms)
        {
            try
            {
                timer = new DispatcherTimer();

                timer.Interval = TimeSpan.FromMilliseconds(interval_ms);
                timer.Tick += new EventHandler(timer_tick);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool init_camera()
        {
            try
            {
                // 0번 카메라로 VideoCapture 생성 (카메라가 없으면 안됨)
                cam = new VideoCapture(0);
                cam.FrameHeight = (int)Cam_1.Height;
                cam.FrameWidth = (int)Cam_1.Width;

                // 카메라 영상을 담을 Mat 변수 생성
                frame = new Mat();

                return true;
            }
            catch
            {
                return false;
            }
        }

        //움직임 스샷 메서드
        //private void timer_tick(object sender, EventArgs e)
        //{
        //    if (!cam.Read(frame)) return; // 프레임 읽기 실패 시 반환

        //    // 첫 번째 실행에서는 이전 프레임을 현재 프레임으로 설정
        //    if (previousFrame.Empty())
        //    {
        //        frame.CopyTo(previousFrame);
        //        return;
        //    }

        //    Mat currentFrameGray = new Mat();
        //    Mat previousFrameGray = new Mat();
        //    Cv2.CvtColor(frame, currentFrameGray, ColorConversionCodes.BGR2GRAY);
        //    Cv2.CvtColor(previousFrame, previousFrameGray, ColorConversionCodes.BGR2GRAY);

        //    // 프레임 간의 차이 계산
        //    Mat diffFrame = new Mat();
        //    Cv2.Absdiff(currentFrameGray, previousFrameGray, diffFrame);
        //    Cv2.Threshold(diffFrame, diffFrame, 25, 255, ThresholdTypes.Binary);

        //    // 움직임 감지를 위한 변화량 계산
        //    int changes = Cv2.CountNonZero(diffFrame);
        //    if (changes > diffFrame.Total() * 0.2) // 전체 픽셀 대비 변경된 픽셀 비율이 20% 이상이면 움직임 감지로 판단
        //    {
        //        Console.WriteLine("움직임 감지됨. 이미지 캡처 중...");
        //        CaptureImage(frame); // 움직임 감지 시 이미지 캡처
        //    }

        //    // 현재 프레임을 이전 프레임으로 업데이트
        //    frame.CopyTo(previousFrame);

        //    // 화면에 프레임 표시
        //    Cam_1.Source = WriteableBitmapConverter.ToWriteableBitmap(frame);
        //}

        ////색깔 검출 매서드
        //private void timer_tick(object sender, EventArgs e)
        //{
        //    if (!cam.Read(frame)) return; // 프레임 읽기 실패 시 반환

        //    Mat hsvFrame = new Mat();
        //    Cv2.CvtColor(frame, hsvFrame, ColorConversionCodes.BGR2HSV); // HSV 색공간으로 변환

        //    Mat mask = new Mat();
        //    Cv2.InRange(hsvFrame, lowerPurple, upperPurple, mask); // 보라색 감지

        //    // 보라색 객체 감지 여부 확인
        //    int count = Cv2.CountNonZero(mask);
        //    if (count > 0) // 보라색 객체 감지 시
        //    {
        //        CaptureImage(frame); // 사진 찍기
        //        Console.WriteLine("보라색 객체 감지됨. 이미지 캡처 중...");
        //    }

        //    // 화면에 프레임 표시
        //    Cam_1.Source = WriteableBitmapConverter.ToWriteableBitmap(frame);
        //}

        //a4 용지 크기만
        private void timer_tick(object sender, EventArgs e)
        {
            if (!cam.Read(frame)) return; // 프레임 읽기 실패 시 반환

            DetectAndCaptureWhiteObject(frame); // 흰색 사각형 감지 및 캡처 메서드 호출

            // 화면에 프레임 표시
            Dispatcher.Invoke(() => // UI 스레드에서 실행 보장
            {
                Cam_1.Source = WriteableBitmapConverter.ToWriteableBitmap(frame);
            });
        }

        private void CaptureImage(Mat frame, OpenCvSharp.Rect rect)
        {
            // 감지된 A4 용지의 테두리에 해당하는 범위만 잘라냅니다.
            Mat croppedImage = new Mat(frame, rect);

            string fileName = $"Capture_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.jpg";
            string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            string fullPath = System.IO.Path.Combine(folderPath, fileName);

            // 잘라낸 이미지를 저장합니다.
            Cv2.ImWrite(fullPath, croppedImage);
            Console.WriteLine($"Image saved: {fullPath}");
        }

        private void Capture_Click(object sender, RoutedEventArgs e)
        {
            // 파일 이름에 현재 날짜와 시간을 포함
            string fileName = $"Capture_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.jpg";
            // 파일을 저장할 경로 지정 (예: 사용자의 "Pictures" 폴더)
            string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            string fullPath = System.IO.Path.Combine(folderPath, fileName);

            // 현재 frame을 JPG 파일로 저장
            Cv2.ImWrite(fullPath, frame);

            // 사용자에게 저장 완료 메시지 표시 (옵션)
            MessageBox.Show($"Image saved: {fullPath}");
        }
        //a4용지 캡쳐
        private void DetectAndCaptureWhiteObject(Mat src)
        {
            // HSV 색공간으로 변환
            Mat hsv = new Mat();
            Cv2.CvtColor(src, hsv, ColorConversionCodes.BGR2HSV);

            // 흰색을 감지하기 위한 HSV 범위 정의
            Scalar lowerWhite = new Scalar(0, 0, 183); // 밝기 최소값 조정
            Scalar upperWhite = new Scalar(180, 25, 255); // 채도 최대값 조정
            Mat mask = new Mat();
            Cv2.InRange(hsv, lowerWhite, upperWhite, mask);

            // 윤곽선 찾기
            Cv2.FindContours(mask, out OpenCvSharp.Point[][] contours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);

            bool currentA4Detected = false;

            foreach (var contour in contours)
            {
                var rect = Cv2.BoundingRect(contour);
                double aspectRatio = (double)rect.Width / rect.Height;
                double area = Cv2.ContourArea(contour);
                double a4AspectRatio = Math.Sqrt(2); // A4 용지의 비율
                double areaThreshold = 3000; // 감지할 최소 면적 설정

                if (Math.Abs(aspectRatio - a4AspectRatio) < 0.15 && area > areaThreshold)
                {
                    currentA4Detected = true;
                    // 마지막 캡처 이후 일정 시간이 지났는지 확인
                    if (!a4DetectedFlag && (DateTime.Now - lastCaptureTime) > captureDelay)
                    {
                        CaptureImage(src, rect);
                        lastCaptureTime = DateTime.Now; // 마지막 캡처 시간 업데이트
                        a4DetectedFlag = true;
                    }
                    Cv2.Rectangle(src, rect, new Scalar(0, 255, 0), 2); // 윤곽선 그리기
                    break; // A4 감지 후 루프 탈출
                }
            }

            // 이번 프레임에서 A4 용지를 감지하지 못했을 경우
            if (!currentA4Detected)
            {
                a4DetectedFlag = false;
            }

            Dispatcher.Invoke(() =>
            {
                Cam_1.Source = WriteableBitmapConverter.ToWriteableBitmap(src);
            });
        }
    }
}
